import * as wasm from "./twetch_sdk_wasm_bg.wasm";
export * from "./twetch_sdk_wasm_bg.js";